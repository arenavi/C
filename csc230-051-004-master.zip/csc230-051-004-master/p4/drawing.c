/**
   @file drawing.c
   @author Amiya Renavikar (arenavi)
   This component defines the main function. It is responsible
   for reading commands from the user and performing them.
   This component also includes some functions that it
   passes to applyToScene() (by address) to perform rotation,
   scaling and translation as needed.
 */
#include "scene.h"
#include "model.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdbool.h>

/* Defines the places where two is to be used/compared. */
#define TWO 2
/* Defines the maximum size of the name array. */
#define MAX_ARRAY 21
/* Defines the maximum length. */
#define MAX_LENGTH 20
/* Defines the maximum size */
#define MAX_SIZE 22
/* Defines the comparison of one where needed. */
#define COMPARE_ONE 1
/* Defines the maximum size of the command. */
#define COMMAND_SIZE 11
/* Defines the X-coordinate. */
#define X 0
/* Defines the Y-coordinate. */
#define Y 1
/* Defines the places where three is to be used/compared. */
#define THREE 3

/**
   Repeatedly calls getchar() until a newline or EOF is found.
 */
void getCharLine()
{
   char ch = getchar();
   while (ch != '\n' && ch != EOF) {
      ch = getchar();
   }
}

/**
   Checks whether the Model is in the Scene.
   @param s Scene pointer.
   @param name of pointer.
 */
bool isModelInScene(Scene * s, char * name ) {
   for ( int i = 0; i < s->mCount; i++ ) {
      if ( strcmp((s->mList[i])->name, name ) == 0) {
        return true;
      }
   }
   return false;
}

/**
   Returns the Model from given name.
   @param s Scene pointer.
   @param name pointer of name.
 */
Model * getModelFromName(Scene *s, char *name){
   for ( int i = 0; i < s->mCount; i++ ) {
            if ( strcmp((s->mList[i])->name, name ) == 0) {
                return s->mList[i];
            }
    }
    return NULL;
}

/**
   Copies one model to the other and creates a new model with
   the same points but a different name.
   @param s Scene pointer.
   @param counter used for command value.
 */
void copy ( Scene *s, int counter )
{
   char destname[MAX_SIZE];
   destname[MAX_LENGTH] = '\0';
   char srcname[MAX_SIZE];
   srcname[MAX_LENGTH] = '\0';
   if ( scanf( "%21s %21s", destname, srcname ) != TWO ) {
     fprintf( stderr, "Command %d invalid\n", counter );
     getCharLine();
     return;
   }
   if ( destname[MAX_LENGTH] != '\0' || srcname[MAX_LENGTH] != '\0' ) {
     fprintf(  stderr, "Command %d invalid\n", counter );
     getCharLine();
     return;
   }
   // check if source name is in the model.
    if (!isModelInScene(s, srcname)) {
        fprintf(  stderr, "Command %d invalid\n", counter );
        getCharLine();
        return;
    }
    // check if destination name already in the model
    if (isModelInScene(s, destname)){
        fprintf(  stderr, "Command %d invalid\n", counter );
        getCharLine();
        return;
    }
    // get the right model with the source name.
    Model *m = getModelFromName(s, srcname);
    Model *cpyM = ( Model * )malloc( sizeof( Model ) );
    cpyM->pCount = m->pCount;
    strcpy(cpyM->name, destname);
    strcpy(cpyM->fname, m->fname);
    cpyM->pList = (double (*)[TWO])malloc(sizeof(double) * TWO * m->pCount * TWO );
    for ( int i = 0; i < m->pCount * 2; i++ ) {
        cpyM->pList[i][0] = m->pList[i][0];
        cpyM->pList[i][1] = m->pList[i][1];
    }
    if ( s->mCount == s->mCap ) {
        s->mList = realloc( s->mList, s->mCap * TWO * sizeof(Model *) );
        s->mCap = s->mCap * TWO;
    }
    s->mList[s->mCount] = cpyM;
    s->mCount++;
}
/**
   This function merges two models together.
   @param s Scene pointer.
   @param counter command counter.
 */
void merge( Scene *s, int counter )
{
   char destname[MAX_SIZE];
   destname[MAX_LENGTH] = '\0';
   char srcname1[MAX_SIZE];
   srcname1[MAX_LENGTH] = '\0';
   char srcname2[MAX_SIZE];
   srcname2[MAX_LENGTH] = '\0';
   if ( scanf( "%21s%21s%21s", destname, srcname1, srcname2 ) != THREE ) {
     fprintf(stderr, "Command %d invalid\n", counter);
     getCharLine();
     return;
   }
   if ( destname[MAX_LENGTH] != '\0' ||
        srcname1[MAX_LENGTH] != '\0' ||
        srcname2[MAX_LENGTH] != '\0' ) {
     fprintf(stderr, "Command %d invalid\n", counter);
     getCharLine();
     return;
   }
   int x = 0, y = 0;
   Model *m1 = NULL;
   Model *m2 = NULL;
   for ( int i = 0; i < s->mCount; i++ ) {
      if ( strcmp( ( s->mList[i] )->name, srcname1 ) == 0 ) {
         m1 = s->mList[i];
         x = i;
      }
      if ( strcmp( ( s->mList[i] )->name, srcname2 ) == 0 ) {
         m2 = s->mList[i];
         y = i;
      }
      if ( strcmp( ( s->mList[i] )->name, destname ) == 0 ) {
         fprintf(stderr, "Command %d invalid\n", counter);
         getCharLine();
         return;
      }
   }
   if ( !m1 || !m2 ) {
      fprintf(stderr, "Command %d invalid\n", counter);
      getCharLine();
      return;
   }

   Model *merge = ( Model * )malloc(sizeof(Model));
   strcpy(merge->name, destname);
   merge->pCount = m1->pCount + m2->pCount;
   strcpy(merge->fname, "-");
   merge->pList = (double (*)[TWO])malloc(TWO * merge->pCount * TWO * sizeof(double));
   for (int i = 0; i < m1->pCount * TWO; i++) {
      merge->pList[i][X] = m1->pList[i][X];
      merge->pList[i][Y] = m1->pList[i][Y];
   }
   
   for (int i = 0; i < m2->pCount * TWO; i++) {
      merge->pList[m1->pCount + i][X] = m2->pList[i][X];
      merge->pList[m1->pCount + i][Y] = m2->pList[i][Y];
   }
   
   freeModel( s->mList[x] );
   freeModel( s->mList[y] );
   if ( s->mCap == s->mCount ) {
      s->mList = realloc(s->mList, TWO * s->mCount * sizeof(Model *));
      s->mCap = s->mCap * TWO;
   }
   s->mList[s->mCount] = merge;
   s->mCount++;
   freeModel(merge);
   
}

/**
   The function compares two separate models using the qsort method.
   @param m1 first Model.
   @param m2 second Model.
 */
int compare( const void * m1, const void * m2 )
{
   Model *x = *(Model **) m1;
   Model *y = *(Model **) m2;
   int str = strcmp( x->name, y ->name );
   return str;
}

/**
   This is the starting point of the program. The function
   prompts the user for commands to load the drawing and scene,
   and allows the user to store anf manipulate two dimensional
   scenes.
 */
int main( void )
{
   Scene *s = makeScene();
   char cmd[COMMAND_SIZE] = "";
   int counter = COMPARE_ONE;
   while ( ( strcmp( "quit", cmd ) != 0 ) )    {
      printf( "cmd %d> ", counter );
      int match = scanf( "%10s", cmd );
      if ( match == EOF ) {
         freeScene( s );
         return EXIT_SUCCESS;
      }
      
      if ( strcmp( cmd, "load" ) == 0 ) {
         char name[MAX_ARRAY] = "";
         scanf( "%21s", name );
         if ( strlen( name ) > MAX_ARRAY - 1 ) {
            fprintf(  stderr, "Command %d invalid\n", counter );
            char valid = getchar();
            
            while ( valid != EOF && valid != '\n' ) {
               valid = getchar();
            }
         } else {
            char fname[MAX_ARRAY] = "";
            scanf( "%21s", fname );
            if ( strlen( fname ) > MAX_ARRAY - 1 ) {
               fprintf(  stderr, "Command %d invalid\n", counter );
               char valid = getchar();
               while ( valid != EOF && valid != '\n' ) {
                 valid = getchar();
               }
            } else {
               Model *m = loadModel ( fname );
               if ( m != NULL ) {
                  strcpy( m -> name, name );
                  if ( ! ( addModel( s, m ) ) ) {
                     fprintf(  stderr, "Command %d invalid\n", counter );
                  }
               }
            }
         }
    } else if ( strcmp( cmd, "save" ) == 0 ) {
         char fname[MAX_ARRAY] = "";
         scanf( "%21s", fname );
         if ( strlen( fname ) > MAX_ARRAY - 1 ) {
            fprintf(  stderr, "Command %d invalid\n", counter );
            char valid = getchar();
            while ( valid != EOF && valid != '\n' ) {
               valid = getchar();
            }
         } else {
            FILE *fstream = fopen( fname, "w" );
            if ( ! fstream ) {
               fprintf( stderr, "Can't open file: %s\n", fname );
            } else {
               qsort( s->mList, s->mCount, sizeof(Model *), compare );
                  for ( int i = 0; i < (s->mCount); i++ ) {
                     for (int j = 0; j < ( s->mList[i]->pCount ) * TWO; j++) {
                        fprintf( fstream, "%.3lf %.3lf\n", s->mList[i]->pList[j][0],
                                s->mList[i]->pList[j][COMPARE_ONE] );
                        if ( j % TWO != 0 ) {
                           fprintf( fstream, "\n" );
                        }
                     }
                  }
            }
            
            fclose( fstream );
         }
    } else if ( strcmp( cmd, "delete" ) == 0 ) {
         char name[MAX_ARRAY] = "";
         scanf( "%21s", name );
         bool valid = false;
         for ( int i = 0; i < s->mCount; i++ ) {
            if ( strcmp( s->mList[i]->name, name ) == 0 ) {
               valid = true;
               Model *m2 = s->mList[i];
               for (int j = i; j < ( s->mCount); j++) {
                  s->mList[j] = s->mList[ j + COMPARE_ONE ];
               }
               freeModel( m2 );
               s->mCount--;
            }
         }
         
         if ( !valid ) {
            fprintf( stderr, "Command %d invalid\n", counter );
            char val = getchar();
            while (val != EOF && val != '\n' ) {
                val = getchar();
            }
         }
      } else if ( strcmp( cmd, "list" ) == 0 ) {
         qsort( s->mList, s->mCount, sizeof(Model *), compare );
         for ( int i = 0; i < s->mCount; i++ ) {
            printf( "%s %s (%d)\n", s->mList[i]->name, s->mList[i]->fname,
                        s->mList[i]->pCount );
         }
      } else if ( strcmp( cmd, "translate" ) == 0 ) {
            double x, y;
            char name[MAX_ARRAY] = "";
            if ( scanf( "%21s", name ) != COMPARE_ONE ||
                 scanf("%lf", &y ) != COMPARE_ONE ||
                 scanf("%lf", &x ) != COMPARE_ONE ) {
               fprintf( stderr, "Command %d invalid\n", counter );
               char val = getchar();
               while ( val != EOF && val != '\n' ) {
                  val = getchar();
               }
            } else if ( !applyToScene(s, name, translate, x, y ) ) {
                fprintf(stderr, "Command %d invalid\n", counter );
            }
      } else if ( strcmp ( cmd, "scale") == 0 ) {
            char name[MAX_ARRAY];
            double sc;
            if ( ( scanf("%21s", name ) != COMPARE_ONE) || ( scanf("%lf", &sc ) != COMPARE_ONE ) ) {
               fprintf( stderr, "Command %d invalid\n", counter);
               char val = getchar();
               while ( val != EOF && val != '\n' ) {
                  val = getchar();
               }
            } else if ( !applyToScene( s, name, scale, sc, 0 ) ) {
               fprintf( stderr, "Command %d invalid\n", counter );
            }
        } else if ( strcmp( cmd, "rotate" ) == 0 ) {
            char name[MAX_ARRAY] = "";
            double degree;
            if ( scanf( "%21s", name ) != COMPARE_ONE ||
                 scanf("%lf", &degree ) != COMPARE_ONE ) {
               fprintf( stderr, "Command %d invalid\n", counter );
               char val = getchar();
               while ( val != EOF && val != '\n' ) {
                  val = getchar();
               }
            } else if ( !applyToScene( s, name, rotate, degree, 0 ) ) {
               fprintf( stderr, "Command %d invalid\n", counter );
            }
        } else if ( strcmp( cmd, "copy" ) == 0 ) {
           copy ( s, counter );
        } else if ( strcmp( cmd, "merge" ) == 0 ) {
           merge( s, counter );
        } else if ( ( strcmp( cmd, "quit") != 0 ) && ( *cmd != EOF ) ) {
           fprintf( stderr, "Command %d invalid\n", counter );
           getCharLine();
        }
        counter++;
    }
    freeScene(s);
    return EXIT_SUCCESS;
}
