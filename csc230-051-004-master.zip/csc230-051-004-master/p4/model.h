#ifndef _MODEL_H_
#define _MODEL_H_

#include <stdio.h>

/** Maximum length of name and filename strings. */
#define NAME_LIMIT 20

/** Representation for a model, a collection of line segments. */
typedef struct {
  /** Name of the model. */
  char name[ NAME_LIMIT + 1 ];
  
  /** File name it was loaded from. */
  char fname[ NAME_LIMIT + 1 ];
  
  /** Number of points in the model.  It has half this many line segments. */
  int pCount;

  /** List of points in the model, twice as long as the number
      of segments, since each segment has two points */
  double (*pList)[ 2 ];
} Model;

/**
    Scales the model by the given floating point value.
    @param pt[2] array that contains X and Y coordinates of scaling.
    @param double value used to store scale value.
    @param garbage variable not used by function.
 */
void scale( double *, double, double);

/**
    Reads the Model from a file and returns a prointer to a
    dynamically allocated instance of model.
    @param *fname input file.
    @return Model pointer to be loaded.
 */
Model *loadModel( char const * );

/**
    Frees the dynamically allocated memory that contains the Model.
    @param *m freed Model.
 */
void freeModel( Model * );

/**
    Transforms the model by certain provided coordinates.
    @param pt[2] array containing the X and Y coordinates of translation.
    @param x X-coordinate.
    @param y Y-coordinate.
 */
void translate( double *, double, double);

/**
    Allows the main program to transform the points in the Model.
    @param *m Model pointer.
    @param *f function transformation.
    @param double value to specify transformation parameters.
    @param double value to specify transformation parameters.
 */
void applyToModel( Model *, void ( double *, double, double ), double, double );

/**
    Rotates the model at the provided angle.
    @param pt[2] array containing X and Y coordinates of rotating.
    @param double value used to store the angle.
    @param garbage variable not used by function.
 */
void rotate( double *, double, double);
#endif
