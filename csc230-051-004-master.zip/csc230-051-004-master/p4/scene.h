#ifndef _SCENE_H_
#define _SCENE_H_

#include "model.h"
#include <stdbool.h>

/** Representation for a whole scene, a collection of models. */
typedef struct {
  /** Number of models in the scene. */
  int mCount;
  
  /** Capacity of the model list. */
  int mCap;

  /** List of pointers to models. */
  Model **mList;
} Scene;

/**
    This function dynamically allocates an instance of Scene.
    @return Scene object of Scene struct.
 */
Scene *makeScene();

/**
    This function goes through the list of models, finds one with a name matching
    the given name and uses the given function to apply a transformation to the
    model (scaling, translation or rotation).
    @param *s Scene location of the Model.
    @param *name name of the Model.
    @param *f function transformation.
    @param double value to specify transformation parameters.
    @param double value to specify transformation parameters.
    @return true if the transformation is applied, false if not.
 */
bool applyToScene ( Scene *, char const *, void ( double *, double, double ), double, double );

/**
    This function frees the dynamically allocated memory
    that stores the given scene.
    @param *s Scene that is freed.
 */
void freeScene( Scene *);

/**
    Adds the Model to the given Scene.
    @param *s Scene to add the model to.
    @param *m Model to add.
    @return true if the Model is added properly, false if not.
 */
bool addModel( Scene *, Model *);
#endif
