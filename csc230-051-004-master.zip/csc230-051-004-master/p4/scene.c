/**
   @file scene.c
   @author Amiya Renavikar (arenavi)
   Defines the Scene struct, in the header, and the functions
   for working with the scene in the implementation file.
 */
#include "scene.h"
#include "model.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

/* Initial capacity of the mList. */
#define INITIAL_CAP 5
/* Array of size 2. */
#define ARRAY_LIM 2

/**
   Dynamically allocates an instance of Scene and initializes
   its fields.
   @return s Scene that is created.
 */
Scene *makeScene()
{
   //Use malloc to dynamically allocate memory.
   Scene *s = ( Scene * )malloc( sizeof( Scene ) );
   s->mList = ( Model ** )malloc( INITIAL_CAP * sizeof ( Model) );
   s->mCap = INITIAL_CAP;
   s->mCount = 0;
   return s;
}

/**
   This function adds the Model to the Drawing.
   @param s scene pointer.
   @param m model pointer.
   @return true if Model is added, false otherwise.
 */
bool addModel( Scene *s, Model *m )
{
   for (int i = 0; i < ( s->mCount ); i++) {
      if ( strcmp( s->mList[i]->name, m->name ) == 0) {
         return false;
      }
   }
   s->mList[s->mCount] = m;
   s->mCount++;
   
   if ( s->mCount >= s->mCap ) {
      s->mCap += INITIAL_CAP;
      s->mList = ( Model ** )realloc( s->mList, s->mCap * sizeof( Model ) );
   }
   
   return true;
}

/**
   This function frees all the dynamically allocated memory
   used by a scene, including the scene object itself, its
   resizable array of Model pointers, and the Model instances.
   @param s instance of Scene.
 */
void freeScene( Scene *s )
{
   for ( int i = 0; i < ( s->mCount ); i++ ) {
      freeModel(s->mList[i] );
   }
   
   free( s->mList );
   free( s );
}

/**
   This function goes through the list of models,
   finds one with a name matching the given name and
   uses the given function to apply a transformation
   to the model (scaling, translation or rotation).
   @param s Scene pointer.
   @param name name of Model.
   @param f function pointer for transformation.
   @param a value for parameter a.
   @param b value for parameter b.
   @return true if the model is found, false otherwise.
 */
bool applyToScene( Scene *s, char const *name, void (*f)(double pt[ARRAY_LIM],
                   double a, double b), double a, double b )
{
   for ( int i = 0; i < (s->mCount); i++ ) {
        if ( strcmp( s->mList[i]->name, name ) == 0) {
            applyToModel( s-> mList[i], f, a, b );
            return true;
        }
   }
   return false;
}
