/**
   @file model.c
   @author Amiya Renavikar (arenavi)
   Defines the Model struct and all functions working directly
   with models.
 */
#include "model.h"
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

/* Defines the maximum length of the array. */
#define ARRAY_MAX 2
/* Defines all the values that require comparison for 1. */
#define COMPARE_ONE 1
/* Defines the initial capacity for pList during allocation. */
#define CAP 10
/* Defines the value of pi wherever needed. */
#define PI 3.1415926536
/* Defines the maximum degree of rotation. */
#define ONE_EIGHTY 180
/* Defines the places where four need sto be used. */
#define FOUR 4
/**
   This function reads a model from a file with the given name,
   returning a pointer to a dynamically allocated instance of model,
   with its pList field pointing to a dynamically allocated array of
   the endpoints of all the segments in the model.
   @param constant file name to read the model from.
   @return m pointer to the dynamically allocated instance of model.
 */
Model *loadModel( char const *fname )
{
   Model *m = ( Model * )malloc( sizeof( Model ) );
   m->pCount = 0;
   int pC = 0;
   int counter = 0;

   FILE *f = fopen( fname, "r" );
   if ( !f ) {
      fprintf( stderr, "Can't open file: %s\n", fname );
      return NULL;
   }

   double ( *pList )[ ARRAY_MAX ];
   pList = ( double( * )[ ARRAY_MAX ])malloc( pC * sizeof( *pList ));
   double a = 0;
   double b = 0;

   int nEOF = 0;
   while ( nEOF == 0 ) {
      int matchesA = fscanf( f, "%lf", &a );
      int matchesB = fscanf( f, "%lf", &b );
      if (matchesA == EOF || matchesB == EOF) {
         nEOF = COMPARE_ONE;
      } else if (matchesA != COMPARE_ONE || matchesB != COMPARE_ONE ) {
         fprintf( stderr, "Invalid model format: %s\n", fname );
         return NULL;
      }
      pList[ counter ][ 0 ] = a;
      pList[ counter ][ COMPARE_ONE ] = b;
      counter++;
      if (counter >= pC) {
         pC = counter + CAP;
         pList = (double(*)[ARRAY_MAX])realloc( pList, pC * sizeof(*pList) );
      }
   }
   m->pList = pList;
   m->pCount = counter / ARRAY_MAX;
   strcpy( m->fname, fname );
   fclose(f);
   return m;
}

/**
   This function frees the dynamically allocated memory used
   to store the given Model, including the structure itself and
   the list of points.
   @param m Model used to free memory.
 */
void freeModel( Model *m )
{
   free( m->pList );
   free( m );
}

/**
   This function rotates the Model. This is an additional function.
   @param pointer array.
   @param a double for parameter a.
   @param b double for parameter b.
 */
void rotate( double pt[ARRAY_MAX], double a, double b)
{
    double x = pt[0];
    double y = pt[1];
    pt[0] = x * cos( a * ( PI / ONE_EIGHTY ) ) - y * sin( a * (PI / ONE_EIGHTY ) );
    pt[COMPARE_ONE] = x * sin( a * ( PI / ONE_EIGHTY ) ) + y * cos( a * ( PI / ONE_EIGHTY ) );

}

/**
   This function translates the Model to a different location.
   This is an additional function.
   @param pointer array of 2.
   @param x x-coordinate.
   @param y y-coordinate.
 */
void translate( double pt[ARRAY_MAX], double x, double y )
{
    pt[0] += y;
    //One compares to y.
    pt[COMPARE_ONE] += x;
}
/**
   This function allows the main program to apply transformations
   to the points in the model.
   @param m Model pointer to apply transformation.
   @param f pointer to a function to be applied.
   @param a the value passed for parameter a.
   @param b the value passed for parameter b.
 */
void applyToModel( Model *m, void (*f)( double pt[ARRAY_MAX], double a, double b),
                   double a, double b )
{
   for (int i = 0; i < m->pCount*ARRAY_MAX; i++ ) {
      f(m->pList[i], a, b);
   }
}

/**
   This function brings the Model to scale. This is an additional
   function.
   @param pointer array of 2.
   @param a double for parameter a.
   @param b double for parameter b.
 */
void scale( double pt[ARRAY_MAX], double a, double b )
{
    //Compare both 0 and 1 to a.
    pt[0] *= a;
    pt[COMPARE_ONE] *= a;
}
