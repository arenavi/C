/**
   @file decrypt.c
   @author Amiya Renavikar (arenavi)
   This component will implement the main function of the decrypt program.
   It will be responsible for handling the command-line arguments, using the bits
   component to read codes from the input file, using the codes component to
   convert them back to characters and writing those to the output file.
 */
#include "bits.h"
#include "codes.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

/** Index of input file. */
#define INP_IDX 1
/** Index of output file. */
#define OUT_IDX 2
/** Number of arguments. */
#define COUNTER 3
/** Invalid return status of code. */
#define F_FAIL -1
/** Invalid return status of reading bits. */
#define BIT_FAIL -2

/**
   The main function is the starting point for the decrypt program.
   It uses the codes and bits components to convert codes back to
   to characters and write them to an output file.
   @param argc number of command line arguments.
   @param *argv command-line args array.
   @return exit status success if program runs successfully, failure otherwise.
 */
int main ( int argc, char *argv[] )
{
   if ( argc != COUNTER ) {
     fprintf( stderr, "usage: decrypt <infile> <outfile>\n" );
     return EXIT_FAILURE;
   }
   
   FILE *fstream = fopen ( argv[INP_IDX], "rb" );
   if ( !fstream ) {
     perror( argv[INP_IDX] );
     return EXIT_FAILURE;
   }
   FILE *f = fopen( argv[OUT_IDX], "w" );
   if ( !f ) {
     perror( argv[OUT_IDX] );
     fclose( fstream );
     return EXIT_FAILURE;
   }
   int temp;
   BitBuffer *buffer = ( BitBuffer * ) malloc ( sizeof( BitBuffer ) );
   buffer->bits = 0;
   buffer->bcount = 0;
   while ( ( temp = readBits( buffer, fstream ) ) > 0 ) {
     int c = codeToSym( temp );
     if ( c == F_FAIL ) {
       fprintf( stderr, "Invalid file\n" );
       free( buffer );
       fclose( fstream );
       fclose( f );
       return EXIT_FAILURE;
     }
     fprintf( f, "%c", c );
   }
   
   if ( temp == BIT_FAIL ) {
      fprintf( stderr, "Invalid file\n" );
      free( buffer );
      fclose( fstream );
      fclose( f );
      return EXIT_FAILURE;
   }
   //Free and close.
   free( buffer );
   fclose( fstream );
   fclose( f );
   return EXIT_SUCCESS;
}
