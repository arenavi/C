/**
   @file codes.c
   @author Amiya Renavikar (arenavi)
   This component contains functions to help map between symbols
   and the codes used to represent them.
 */
#include "codes.h"

/** Defines the index of the space character. */
#define INDEX 26
/** Defines the index of the new line character. */
#define NEW_INDEX 27
/** Defines the places that require the number one. */
#define ONE 1
/** Defines the shifting of index in the conversionTable. */
#define SHIFT 65
/** Defines the index that contains last alphabet. */
#define ALPHA 25
/** Defines the last index in the conversion table. */
#define TABLE 28
/** Maximum number of bits. */
#define MAX_BITS 12
/** Defines the return status of failure. */
#define F_FAIL -1

/** This global variable defines an array to hold each of the codes. */
static int conversionTable[] = { 0x2C, 0x354, 0x6B4, 0xD4, 0x4, 0x2B4, 0x1B4, 0x154,
                              0x14, 0xB6C, 0x1AC, 0x2D4, 0x6C, 0x34, 0x36C, 0x5B4,
                              0xDAC, 0xB4, 0x54, 0xC, 0xAC, 0x2AC, 0x16C, 0x6AC,
                              0xD6C, 0x6D4, 0x5AC, 0x56C };
/**
   This function returns the number of bits in the code used to represent it.
   @param ch the unsigned char used to determine no. of bits.
   @return temp number of bits to store ch, else -1 if no code to represent character.
 */
int bitsInCode( unsigned char ch )
{
   int code;
   int temp = 0;
   if ( ( code = symToCode( ch ) ) == F_FAIL ) {
     return F_FAIL;
   }
   for ( int i = 0; i < MAX_BITS; i++ ) {
     if ( ( code & ONE ) == ONE ) {
       temp = i + ONE;
   }
   code = code >> ONE;
   }
   return temp;
}

/**
   This function returns the code used to represent it, given the ASCII
   code for a character.
   @param ch unsigned char to convert.
   @return code used to represent the char, or -1 if no code present.
 */
int symToCode( unsigned char ch )
{
   if ( ch >= 'A' && ch <= 'Z' ) {
      return conversionTable[ ch - SHIFT ];
   }
   
   if ( ch == '\n' ) {
      return conversionTable[ NEW_INDEX ];
   }
   
   if ( ch == ' ' ) {
      return conversionTable[ INDEX ];
   }
   return F_FAIL;
}

/**
   This function, given a code returns the ASCII character
   it represents.
   @param code the code to be converted.
   @return character that represents the given code, or -1 if the code does not
    represent a character.
 */
int codeToSym( int code )
{
   int idx;
   for ( idx = 0; idx < TABLE; idx++ ) {
     if ( conversionTable[ idx ] == code ) {
       break;
     }
   }
   if ( idx >= 0 && idx <= ALPHA ) {
    return idx + SHIFT;
   }
   if ( idx == NEW_INDEX ) {
     return '\n';
   }
   if ( idx == INDEX ) {
     return ' ';
   }
   return F_FAIL;
}
