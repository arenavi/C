/**
   @file encrypt.c
   @author Amiya Renavikar (arenavi)
   This component handles command-line arguments, reads command
   characters from input file, using codes component to convert
   them into codes and using the bits component to write them
   out to an output file.
 */
#include "bits.h"
#include "codes.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

/** Index of input file. */
#define INP_IDX 1
/** Index of output file. */
#define OUT_IDX 2
/** Number of arguments. */
#define COUNTER 3
/** Invalid return status. */
#define F_FAIL -1

/**
   The main function is the starting point for the encrypt program.
   It uses the codes and bits components to convert characters into
   codes and write them to an output file.
   @param argc number of command line arguments.
   @param *argv command-line args array.
   @return exit status success if program runs successfully, failure otherwise.
 */
int main ( int argc, char *argv[] )
{
   if ( argc != COUNTER ) {
     fprintf( stderr, "usage: encrypt <infile> <outfile>\n" );
     return EXIT_FAILURE;
   }
   FILE *fstream = fopen ( argv[INP_IDX], "r" );
   if ( !fstream ) {
     perror( argv[INP_IDX] );
     return EXIT_FAILURE;
   }
   FILE *f = fopen( argv[OUT_IDX], "wb" );
   if ( !f ) {
     fclose( fstream );
     perror( argv[OUT_IDX] );
     return EXIT_FAILURE;
   }
   BitBuffer *buffer = ( BitBuffer * ) malloc ( sizeof( BitBuffer ) );
   buffer->bits = 0;
   buffer->bcount = 0;
   unsigned char r;
   while ( EOF != ( fscanf( fstream, "%c", &r ) ) ) {
     if ( ( r < 'A' || r > 'Z') &&
            r != '\n' &&
            r != ' ' ) {
       fprintf( stderr, "Invalid file\n" );
       free( buffer );
       fclose( fstream );
       fclose( f );
       return EXIT_FAILURE;
     }
     int symbol = symToCode( r );
     if ( symbol == F_FAIL ) {
       fprintf( stderr, "Invalid file\n" );
       free( buffer );
       fclose( fstream );
       fclose( f );
       return EXIT_FAILURE;
     }
     
     int nbits = bitsInCode( r );
     writeBits( symbol, nbits, buffer, f );
   }
   
   flushBits( buffer, f );
   free( buffer );
   fclose( fstream );
   fclose( f );
   return EXIT_SUCCESS;
}
