/**
   @file codes.h
   @author Amiya Renavikar (arenavi)
   The header file declares the three functions for usage for mapping between
   symbols and the codes used to represent them.
 */
 
 /**
   This function returns the number of bits in the code used to represent it.
   @param ch the unsigned char used to determine no. of bits.
   @return temp number of bits to store ch, else -1 if no code to represent character.
 */
int bitsInCode( unsigned char ch );

/**
   This function returns the code used to represent it, given the ASCII
   code for a character.
   @param ch unsigned char to convert.
   @return code used to represent the char, or -1 if no code present.
 */
int symToCode( unsigned char ch );

/**
   This function, given a code returns the ASCII character
   it represents.
   @param code the code to be converted.
   @return character that represents the given code, or -1 if the code does not
    represent a character.
 */
int codeToSym( int code );
