/**
   @file jumble.c
   @author Amiya Renavikar (arenavi)
   
   The program reads a list of dictionary words and helps the
   user guess answers by showing words that contain a given group
   of letters.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

/** To compare output for scanf. */
#define SCANF_OUT 1
/** Defines the maximum number of words. */
#define MAX_WORDS 100000
/** Defines the maximum number of columns. */
#define MAX_COLUMNS 21
/** Defines the maximum length of the word. */
#define MAXWORD_LEN 20
/** Defines the maximum number of command line arguments. */
#define MAX_ARGS 2
/** Defines the maximum number of words in a dictionary. */
#define WORD_INDEX 99999
/** Defines the exit status for when a file cannot be opened. */
#define CANNOT_OPEN_FILE 1
/** Defines the exit status for when a file is invalid. */
#define INVALID_FILE 1
/** Defines the exit status for when the command line arg is incorrect. */
#define INCORRECT_ARG 1
/** Global variable to store the word list. */
char words [MAX_WORDS] [MAX_COLUMNS];
/** Integer representing the number of words in the word list. */
int wordCount = 0;

/**
   This function reads the word list from the file with
   the given name and stores it in the global words array and sets wordCount.
   @param *filename name of the input file.
 */
void readWords( char const *filename )
{
  FILE *f = fopen( filename, "r" );
  if ( !f ) {
    fprintf( stderr, "Can't open word file\n" );
    exit ( CANNOT_OPEN_FILE );
  }
  
  int row = 0;
  int col = 0;
  
  char ch = fgetc ( f );
  while ( ch != EOF ) {
    if (( ch != '\n' && (ch < 'a' || ch > 'z')) || row > WORD_INDEX || col >
          MAXWORD_LEN ) {
      fprintf( stderr, "Invalid word file\n");
      exit ( INVALID_FILE );
    }
    
    if ( ch == '\n' ) {
      words[row][col] = '\0';
      row++;
      col = 0;
      ch = fgetc( f );
    } else {
      words[row][col] = ch;
      col++;
      ch = fgetc( f );
    }
  }
  wordCount = row;
}

/**
   This function prompts the user for letters and stores them in
   the given letters array.
   @param letters character array.
   @return true if user enters a valid input, and false if not.
 */
bool getLetters( char *letters )
{
  printf( "letters> ");
  char ch = getchar();
  int idx = 0;
  bool valid = true;
  while ( ch != EOF ) {
    if ( ch == '\n' && valid ) {
        letters[idx] = '\0';
        return true;
    } else if ( ch == '\n' && !valid ) {
        printf( "Invalid letters\nletters> " );
        idx = 0;
        valid = true;
        ch = getchar();
        continue;
    }
    if ( ch > 'z' || ch < 'a' || idx > MAXWORD_LEN ) {
      valid = false;
    }
    if (valid) {
      letters[idx] = ch;
    }
    idx++;
    ch = getchar();
  }
  if ( idx == 0 ) {
    return false;
  }

  return valid;
}

/**
   This function returns true if the given word matches the
   given letters, and returns false if there is no match.
   @param *word given word.
   @param *letters given letters.
   @return true if there is a match between words and letters.
 */
bool matches( char const *word, char const *letters )
{
   if (strlen(word) != strlen(letters)) {
     return false;
   }
   for (int i = 0; i < strlen(letters); i++) {
      int a = *(letters + i);
      int aC = 0;
      int bC = 0;
      for (int j = 0; j < strlen(letters); j++) {
         if (*(letters + j) == a) {
             aC++;
         }
      }
      for (int j = 0; j < strlen(word); j++) {
         if (*(word + j) == a) {
             bC++;
         }
      }
      
      if (aC != bC) {
        return false;
      }
   }
   return true;
}

/**
   This is the starting point of the program. The program reads in a
   list of dictionary words and then helps the user guess answers by
   showing words that contain a given group of letters. The program
   returns an exit status of 1 if the number of command-line
   arguments does not equal 2.
   @param argc passed in command-line arguments.
   @param *argv[] value of the command-line args.
   @return exit status of 0 if program runs successfully, 1
           if the number of command-line args is not equal to 2.
 */
int main( int argc, char *argv[] )
{
  if ( argc != MAX_ARGS ) {
    fprintf( stderr, "usage: jumble <word-file>" );
    exit( INCORRECT_ARG );
  }
  char letters[ MAX_COLUMNS ];
  readWords( argv[ SCANF_OUT ] );
  while ( getLetters(letters) ) {
    for ( int i = 0; i < wordCount; i++ ) {
      if ( matches( *( words + i), letters ) ) {
        printf( "%s\n", *( words + i) );
      }
    }
  }
  return EXIT_SUCCESS;
}
