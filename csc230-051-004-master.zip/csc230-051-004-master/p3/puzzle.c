/**
   @file puzzle.c
   @author Amiya Renavikar (arenavi)

   This program creates and outputs a Jumble crossword puzzle by
   taking in a file name from a command-line argument.
 */
#include "grid.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/** Defines various places that need an exit status of 1. */
#define EXIT_ONE 1
/** Defines the maximum number of arguments. */
#define MAX_ARGS 2
/** Defines the maximum no. of rows and columns. */
#define MAX_ROWS_COLS 40
/** Defines the maximum no. of letters. */
#define MAX_LETTERS 10
/** Defines the array size for the given word. */
#define ARR 11
/** Defines the scanf values to be matched. */
#define SCANN 3
/** Defines the place where scanf reads the file incorrectly. */
#define SCANF_ERR 4

/**
   This is the starting point of the program. The function uses
   a command-line prompt to get an input file by which it prints
   words in a grid format. It also uses grid.c source file's helper
   functions to perform this task.
   @param argc the number of command line arguments.
   @param argv the array that stores the command line arguments.
   @return exit success status
 */
int main ( int argc, char *argv[] )
{
   if ( argc != MAX_ARGS ) {
      fprintf ( stderr, "usage: puzzle <input-file>\n" );
      exit ( EXIT_ONE );
   }

   FILE *fstr = fopen( argv[EXIT_ONE], "r" );
   
   if ( !fstr ) {
      fprintf ( stderr, "usage: puzzle <input-file>\n" );
      exit ( EXIT_ONE );
   }
   
   int rows = 0;
   int cols = 0;
   int numWords = 0;
   if ( SCANN != fscanf ( fstr, "%d%d%d", &rows, &cols, &numWords ) ) {
      fprintf ( stderr, "Invalid input file\n" );
      exit ( EXIT_ONE );
   }
   
   if ( rows > MAX_ROWS_COLS || cols > MAX_ROWS_COLS || numWords < EXIT_ONE ) {
      fprintf ( stderr, "Invalid input file\n" );
      exit ( EXIT_ONE );
   }
   
   char grid[rows][cols];
   
   for ( int i = 0; i < rows; i++ ) {
      for ( int j = 0; j < cols; j++ ) {
         grid[i][j] = ' ';
      }
   }
   
   for ( int i = 0; i < numWords; i++ ) {
      char orient;
      int rpos = 0;
      int cpos = 0;
      char word[ARR];
      word[MAX_LETTERS] = '\0';
      
      if ( SCANF_ERR != fscanf( fstr, "%*c%c%d%d%11s", &orient, &rpos,
          &cpos, word ) ) {
         fprintf( stderr, "Invalid input file\n" );
         exit( EXIT_ONE );
      }
      //Check again for invalid input file.
      if (( orient != 'H' && orient != 'V') || strlen(word) > MAX_LETTERS ) {
         fprintf( stderr, "Invalid input file\n" );
         exit( EXIT_ONE );
      }
      //Check orientation.
      if ( orient == 'V' ) {

         writeVertical( rpos, cpos, word, rows, cols, grid );

      } else {

         writeHorizontal(rpos, cpos, word, rows, cols, grid );
      }
   }
   //Print grid here.
   printGrid( rows, cols, grid );
   int fclose ( FILE *fstr );
   return EXIT_SUCCESS;
}
