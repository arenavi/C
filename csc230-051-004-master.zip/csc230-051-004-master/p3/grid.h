/**
    This function uses it parameters to modify the grid so that
    the given word is written to the grid horizontally at given
    position.
    @param rpos row position of the first letter.
    @param cpos column position of the first letter.
    @param word char array of letters containing word to write.
    @param rows number of rows in the grid.
    @param cols number of columns in the grid.
    @param grid 2-D representation of the grid.
 */
void writeHorizontal( int rpos, int cpos, char word[], int rows, int cols, char grid[rows][cols] );

/**
    This function uses it parameters to modify the grid so that
    the given word is written to the grid vertically at given
    position.
    @param rpos row position of the first letter.
    @param cpos column position of the first letter.
    @param word char array of letters containing word to write.
    @param rows number of rows in the grid.
    @param cols number of columns in the grid.
    @param grid 2-D representation of the grid.
 */
void writeVertical( int rpos, int cpos, char word[], int rows, int cols, char grid[rows][cols] );

/**
    This function prints the grid to standard output using rows and columns.
    @param rows number of rows in the grid.
    @param cols number of columns in the grid.
    @param grid 2-D representation of the grid.
 */
void printGrid( int rows, int cols, char board[rows][cols] );
