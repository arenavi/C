/**
   @file grid.c
   @author Amiya Renavikar (arenavi)

   This source file program defines three helper functions used in puzzle
   to build a grid.
 */
#include "grid.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/** Defines the places where the number 1 needs to be used. */
#define COMPARE_ONE 1

/**
   This function adds a word to the grid with the first
   letter at row rpos and column cpos with a horizontal
   orientation.
   @param rpos row position to write word.
   @param cpos column position to write word.
   @param word the word to write horizontally.
   @param rows the number of rows in the grid.
   @param cols the number of columns in the grid.
   @param grid the grid to write.
 */
void writeHorizontal( int rpos, int cpos, char word[], int rows, int cols,
                      char grid[ rows ][ cols ] )
{
   //Initialize index.
   int idx = 0;
   //Use while loop to check for invalid input files and write horizontally.
   while ( word[idx] != '\0' ) {
   
      if ( grid[rpos][cpos + idx] != ' ' &&
           word[idx] != grid[rpos][cpos + idx] ) {
         fprintf(stderr, "Invalid input file\n");
         exit(COMPARE_ONE);
      }
      if ( (rpos > rows - COMPARE_ONE) || (cpos + idx > cols - COMPARE_ONE)
            || rpos < 0 || cpos + idx < 0) {
         fprintf(stderr, "Invalid input file\n");
         exit(COMPARE_ONE);
      }
      //Write grid
      grid[rpos][cpos + idx] = word[idx];
      //Increment index
      idx++;
   }
}

/**
   This function adds a word to the grid with the first
   letter at row rpos and column cpos with a vertical
   orientation.
   @param rpos row position to write word.
   @param cpos column position to write word.
   @param word the word to write vertically.
   @param rows the number of rows in the grid.
   @param cols the number of columns in the grid.
   @param grid the grid to write.
 */
void writeVertical( int rpos, int cpos, char word[], int rows, int cols, char grid[ rows ][ cols ] )
{
   //Initialize index.
   int idx = 0;
   //Use while loop to write word vertically.
   while (word[idx] != '\0') {
      //Check for invalid inputs.
      if (grid[rpos + idx][cpos] != ' ' &&
          word[idx] != grid[rpos + idx][cpos] ) {
         fprintf( stderr, "Invalid input file\n" );
         exit( COMPARE_ONE );
      }
      if ( ( rpos + idx > rows - COMPARE_ONE) || ( cpos > cols - COMPARE_ONE )
             || rpos + idx < 0 || cpos < 0 ) {
             
         fprintf( stderr, "Invalid input file\n" );
         exit( COMPARE_ONE );
      }
      //Write grid.
      grid[rpos + idx][cpos] = word[idx];
      //Increment index
      idx++;
   }
}

/**
   This function will print the given grid to standard
   output using the number of rows and columns provided.
   @param rows the number of rows in the grid.
   @param cols the number of columns in the grid.
   @param board the grid to be printed as standard output.
 */
void printGrid( int rows, int cols, char board[rows][cols] )
{
   for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
         if ( j != cols - COMPARE_ONE ) {
            printf("%-2c", board[i][j]);
         } else {
            printf("%c\n", board[i][j]);
         }
      }
   }
}
