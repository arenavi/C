import java.util.*;
import java.io.*;

public class Project2P2Diff{
  // constant
  public static final int row = 100;
  public static final int col = 100;
  
  // variables
  public Scanner console = new Scanner(System.in);
  public Scanner expected = null;
  public Scanner actual = null;
  
  
  public static void main(String [] args){
    new Project2P2Diff().userInterface();
  }
  
  
  public void userInterface(){
    expected = getExpectedScanner(console);
    actual = getActualScanner(console);
    int expectedRed = 0;
    int expectedGreen = 0;
    int expectedBlue = 0;
    int actualRed = 0;
    int actualGreen = 0;
    int actualBlue = 0;
    // discard the first three lines
    for(int i = 0; i < 3; i++){
      expected.nextLine();
      actual.nextLine();
    }

    for(int i = 0; i < row; i++){
      for(int j = 0; j < col; j++){
        expectedRed = expected.nextInt();
        expectedGreen = expected.nextInt();
        expectedBlue = expected.nextInt();
        actualRed = actual.nextInt();
        actualGreen = actual.nextInt();
        actualBlue = actual.nextInt();
        if(expectedRed != actualRed || expectedGreen != actualGreen || expectedBlue != actualBlue){
          System.out.print("Row:" + i + "Col:" + j);
          System.out.print("Expected:(" + expectedRed + "," + expectedGreen + "," + expectedBlue + ")");
          System.out.println("Actual:(" + actualRed + "," + actualGreen + "," + actualBlue + ")");
        }
      }
      
    }
  }
  
  public Scanner getExpectedScanner(Scanner console){
    Scanner input = null;
    while (input == null) {
      System.out.print("Enter expected file: ");
      String filename = console.next();
      try {
        input = new Scanner(new File(filename));
      }
      catch (FileNotFoundException e) {
        System.out.println(e.getMessage());
      }
    }
    return input;
  }
  
  public Scanner getActualScanner(Scanner console){
    Scanner input = null;
    while (input == null) {
      System.out.print("Enter acutal file: ");
      String filename = console.next();
      try {
        input = new Scanner(new File(filename));
      }
      catch (FileNotFoundException e) {
        System.out.println(e.getMessage());
      }
    }
    return input;
  }
}
