/**
   @file voronoi.c
   @author Amiya Renavikar (arenavi)
   
   The program draws a voronoi diagram based on an input file with
   three points, coloring the region closest to the first point in red,
   the region closest to the second point in green, and the region closest
   to the third point in blue.
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/**Image width and height */
#define IMAGE_WH 100

/**String that represents the max color value of the ppm file */
#define MAX_COLOR "255"

/**String that represents the min color value of the ppm file */
#define MIN_COLOR "0"

/**Input value matching */
#define INPUT_VALUE 6

/**Invalid exit input */
#define INVALID_EXIT_INPUT 100

/** Variable that represents the x value (red) */
double x1;

/** Variable that represents the x value (green) */
double x2;

/** Variable that represents the x value (blue) */
double x3;

/** Variable that represents the y value (red) */
double y1;

/** Variable that represents the y value (green) */
double y2;

/** Variable that represents the y value (blue) */
double y3;

/**
   The function returns true if the given pixel is closest
   one to a given point.
   @param col column location of the given pixel.
   @param row row location of the given pixel.
   @param x input point.
   @param y input point.
   @return true if the point is the nearest to the pixel, false otherwise.
 */
bool nearestPoint( int col, int row, double x, double y)
{
    if (col == round(x) && row == round(y)) {
        return true;
    } else {
        return false;
    }
}

/**
   This function prints out the right color for the pixel, using global
   variables for the three input point locations to decide which point
   the pixel is closest to.
   @param col column value of pixel.
   @param row row value of pixel.
 */
void chooseColor( int col, int row)
{
    //distance for red color
    double red = (( x1 - col) * (x1 - col)) + ((y1 - row) * (y1 - row));
    
    //distance for green color
    double green = (( x2 - col) * (x2 - col)) + ((y2 - row) * (y2 - row));
    
    //distance for blue color
    double blue = (( x3 - col) * (x3 - col)) + ((y3 - row) * (y3 - row));
    
    if (red < green && red < blue) {
        printf("%3s %3s %3s ", MAX_COLOR, MIN_COLOR, MIN_COLOR);
    } else if (green < red && green < blue) {
        printf("%3s %3s %3s ", MIN_COLOR, MAX_COLOR, MIN_COLOR);
    } else {
        printf("%3s %3s %3s ", MIN_COLOR, MIN_COLOR, MAX_COLOR);
    }
}

/**
   This is the program's starting point- this function reads all input values
   by the means of scanf and prints out a voronoi diagram using a nested
   for loop.
   @return exit status of the program (0 if the program runs successfully,
    100 if the input file is malformed)
 */
int main()
{
    //Scan input
    int scan1 = scanf("%lf%lf%lf%lf%lf%lf", &x1, &y1, &x2, &y2, &x3, &y3);
    
    //Error checking
    if (scan1 != INPUT_VALUE) {
        printf("Invalid input\n");
        return INVALID_EXIT_INPUT;
    }
    //Print f
    printf("P3\n100 100\n255\n");
    //Build nested for loop
    for (int i = 0; i < IMAGE_WH; i++) {
        for (int j = 0; j < IMAGE_WH; j++) {
            if ((nearestPoint(j, i, x1, y1)) || (nearestPoint(j, i, x2, y2)) 
                 ||(nearestPoint(j, i, x3, y3))) {
                printf("255 255 255 ");
            } else {
                chooseColor(j, i );
            }
        }
        printf("\n");
    }
    
    return EXIT_SUCCESS;
}
