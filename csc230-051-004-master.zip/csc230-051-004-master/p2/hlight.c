/**
   @file hlight.c
   @author Amiya Renavikar (arenavi)
   
   The program reads text from a standard input and outputs
   identical text with HTML tags colored red and HTML entities
   colored blue.
 */
#include <stdio.h>
#include <stdlib.h>


/** Defines an exit status of 100 */
#define EXIT_ENTITY 100
/** Defines an exit status of 101 */
#define EXIT_TAG 101
/** ASCII default code 27 */
#define ESC_CODE 27

/**
   This method colors the HTML tag in red. If the EOF is 
   encountered before the end of the tag, the program will have an exit 
   status of 101 (malformed tag).
*/
void showTag()
{
    //initialize variable.
    int tag = EOF;
    //use while-loop to print default code.
    while ((tag = getchar()) != '>') { 
        if (tag == EOF) {
            putchar(ESC_CODE);
            putchar('[');
            putchar('0');
            putchar('m');
            exit(EXIT_TAG);
        }
        putchar(tag);      
    }
    //print default code again.
    putchar(tag);      
    putchar(ESC_CODE);
    putchar('[');
    putchar('0');
    putchar('m');
}

/**
   This method colors the HTML tag in blue. If the EOF is 
   encountered before the end of the tag, the program will have an exit 
   status of 100 (malformed tag).
 */
void showEntity()
{
    //initialize variable.
    int entity = EOF;
    //use while-loop to print default code.
    while ((entity = getchar()) != ';') { 
        if (entity == EOF) {
            putchar(ESC_CODE);
            putchar('[');
            putchar('0');
            putchar('m');
            exit(EXIT_ENTITY);
        }
        putchar(entity);      
    }
    //print default code again. 
    putchar(entity);      
    putchar(ESC_CODE);
    putchar('[');
    putchar('0');
    putchar('m');
}

/**
   The main method calls the showTag() and showEntity() methods when
   the requirements for the same are met.
   @return exit status for the program.
 */
int main()
{
    //initialize variable.
    int a = EOF;
    //use while loop to check symbol and print the text.
    while ((a = getchar()) != EOF) {
        if (a == '<') {
            putchar(ESC_CODE);
            putchar('[');
            putchar('3');
            putchar('1');
            putchar('m');
            putchar(a);
            showTag();
        } else if (a == '&') {
            putchar(ESC_CODE);
            putchar('[');
            putchar('3');
            putchar('4');
            putchar('m');
            putchar(a);
            showEntity();
        } else {
            putchar(a);
        }
    }
    return EXIT_SUCCESS;
}
